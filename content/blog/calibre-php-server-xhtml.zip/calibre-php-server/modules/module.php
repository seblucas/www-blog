<?php
	/*
		Name:		 Calibre PHP webserver
		License:	 GPL v3
		Copyright:	 2010, Charles Haley
	                 http://charles.haleys.org
	*/

	class Module {

		function check_arguments($db) {
			return false;
		}

		function do_work($smarty, $db) {
			;
		}

		function template() {
			return NULL;
		}
	}
?>